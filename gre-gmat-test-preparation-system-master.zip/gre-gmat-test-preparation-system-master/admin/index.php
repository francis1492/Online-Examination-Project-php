<?php
    include('config/apply.php');
    ob_start();
 
    include('../box/header.php');
    include('../box/menu.php');
    include('pages/main.php');
    include('../box/footer.php');
?>