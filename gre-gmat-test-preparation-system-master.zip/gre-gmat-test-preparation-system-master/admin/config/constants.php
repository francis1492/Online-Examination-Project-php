<?php 
    define('SITEURL','http://localhost:80/gre-gmat-test-preparation-system-master/');
    define('LOCALHOST','localhost');
    define('USERNAME','root');
    define('PASSWORD','');
    define('DBNAME','quizapp');
?>