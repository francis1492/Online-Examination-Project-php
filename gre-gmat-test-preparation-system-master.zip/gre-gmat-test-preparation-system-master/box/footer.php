
<!--Footer Starts Here-->
        <footer class="footer">
            <div class="wrapper">
                <p>
                    <a href="https://youtu.be/zFluXqeu_CM" title="Dzaleka AppFactory">Dzaleka AppFactory</a> &copy; <?php echo date('Y'); ?>. All Rights Reserved.    
                    Powered by <a href="https://youtu.be/zFluXqeu_CM" title="Mayanga Djafari Francis" target="_blank">Mayanga Djafari Francis</a>.
                </p>
            </div>
        </footer>
        <!--Footer Ends Here-->
</html>