<!DOCTYPE html>
<html lang="en-US">
    <head>
        <!--Meta Tags Starts Here-->
        <meta charset="UTF-8" />
        <meta name="author" content="Mayanga Djafari Francis" />
        <meta name="description" content="Online Students-Assessment | Dzaleka Appfactory For Maynaga Djafari Francis." />
        <meta name="keywords" content="Online Students-Assessment  | Dzaleka Appfactory, Online Test, Appfactory 4 Africa, Dzaleka" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <!--Meta Tags Ends Here-->
        <title>Online Students-Assessment  | Dzaleka Appfactory - Mayanga Djafari Francis</title>
        
        <!--COUNT DOWN TIMER STARTS HERE-->
        <script src="<?php echo SITEURL; ?>/assets/js/countdown/jquery.js"></script>
        <script src="<?php echo SITEURL; ?>/assets/js/countdown/jquery.simple.timer.js"></script>
        <script>
          $(function(){
            $('.timer').startTimer();
          });
        </script>
        <!--COUNT DOWN TIMER ENDS HERE-->
        
        <!--ADDING CKEDITOR HERE-->
        <script type="text/javascript" src="<?php echo SITEURL; ?>/assets/ckeditor/ckeditor.js"></script>
        
        <!--CSS File Starts Here-->
        <link rel="stylesheet" type="text/css" href="<?php echo SITEURL; ?>/assets/css/style.css" />
        <!--CSS File Ends Here-->
    </head>
    
    <body>
        <!--Header Starts Here-->
        <header class="header">
            <div class="wrapper clearfix">
                <div class="logo">
                    <img style="border-radius: 25px; box-shadow: rgba(0,0,0,0.8) 0 0 10px;
 border-collapse: collapse;" src="<?php echo SITEURL; ?>/images/logo (2).png" alt="Dzaleka Appfactory 4 Africa" title="Dzaleka Appfactory 4 Africa" />
                </div>
                
                <div class="head-title">
                    <h1>Online Students-Assessment  | Dzaleka Appfactory</h1>
                </div>
            </div>
        </header>
        <!--Header Ends Here-->
